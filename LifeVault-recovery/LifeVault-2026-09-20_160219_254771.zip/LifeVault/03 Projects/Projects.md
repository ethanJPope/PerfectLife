---
type: index
status: active
created: 2026-09-20
updated: 2026-09-20
schema: 1
---

# Projects

| Project | Status | Last evidence | Next action |
|---|---|---|---|
| [[03 Projects/LifeVault setup]] | active | 2026-09-20 | Finish setup verification, then start the initial interview. |

Add a project when Ethan names a concrete outcome. Do not invent projects from interests.
