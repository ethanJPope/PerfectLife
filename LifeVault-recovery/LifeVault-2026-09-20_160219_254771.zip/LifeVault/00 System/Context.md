---
type: system
status: active
created: 2026-09-20
updated: 2026-09-20
schema: 1
---

# Current context

Only facts provided in this fresh-start conversation are included. Other personal details are unknown until the interview.

| Current statement | Evidence | Last confirmed |
|---|---|---|
| The vault is named LifeVault. | [[07 Journal/2026/09/2026-09-20 LifeVault brief#User requirements]] | 2026-09-20 |
| The goal is to remember important information so Ethan does not have to; intended lifespan is at least 3–6 years. | Same brief | 2026-09-20 |
| Clean retrieval, continuity across chats, and clear recency matter. | Same brief | 2026-09-20 |
| Ethan wants proactive questions and specialized skills for onboarding, research, auditing, and teaching. | Same brief | 2026-09-20 |
| Expect to refine the system over 1–3 weeks. | Same brief | 2026-09-20 |

## Focus now
[[03 Projects/LifeVault setup]] — finish initial setup checks, then start the interview. Onboarding has not been completed.

## Important unknowns
Priority life domains, current projects, schedule, devices, learning baseline, preferred backup destination, and concrete examples of information previous systems missed. Ask only when relevant or during onboarding. Do not infer age, diagnoses, finances, or school status from old memory.

## Confirmed setup choices
- Vault location: `D:\PerfectLife\LifeVault`.
- Save useful non-sensitive facts automatically and briefly mention changes.
- Earlier setups were poorly planned and missed key personal information.
- Evidence: [[07 Journal/2026/09/2026-09-20 Setup preferences]], confirmed 2026-09-20.

## Working assumptions, not personal facts
- Low-friction plain Markdown and core Obsidian features are the starting design.
- Ordinary useful self-reports are saved under the user’s current request; sensitive data needs specific approval.
