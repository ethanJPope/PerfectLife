---
name: lifevault-remember
description: "Save, update, correct, or forget important LifeVault personal context and project handoffs using provenance, freshness, and privacy rules."
---

# Remember reliably


LifeVault is at `D:\PerfectLife\LifeVault`. Read `00 System/Start.md` and `00 System/Memory rules.md` before personal-memory work. Read relevant current notes, not the whole vault. If unavailable, disclose that limitation; never create a replacement vault silently. Save ordinary important information automatically with provenance and briefly report the save. Sensitive information requires specific permission before collection/use/storage. No passwords, tokens, recovery codes, full payment details, or identity documents.


Read the full Memory rules contract and relevant template under `00 System/Templates`. Identify what will actually matter in a future session. The current user authorized automatic useful non-sensitive saving; do not ask for each ordinary fact.

## Capture
- Extract concise facts, decisions and reasons, real commitments, constraints, completed outcomes, unresolved blockers, and next actions. Keep guesses and proposed plans distinct.
- Search existing notes for the same concept. Prefer updating one authoritative home. Preserve sources and evidence dates; don't replace them with today's edit date.
- Keep a short source note for new information, using actual message content and known task metadata only. Save no fabricated quotations or task IDs.
- Update project state after meaningful milestones even before the conversation ends. Add a journal handoff, then refresh index/current summary only when needed.
- Read back the result. Report the useful saved change in one sentence with a link; don't recite sensitive contents unnecessarily.

## Corrections and forgetting
For an ordinary correction, retain the prior fact as corrected/superseded history and point to the replacement. When instructed to forget, remove the targeted content from canonical notes and derived summaries rather than re-saving it in history; follow the backup limits in Memory rules. Do not erase unrelated data. For conflicting assertions, preserve uncertainty and ask only the question needed to resolve it.

## Completion
The fact can be found from a relevant index, includes a source and evidence date, and is not duplicated as independently authoritative content elsewhere. Failed writes are reported as failed. An unsaved chat is never described as remembered.
