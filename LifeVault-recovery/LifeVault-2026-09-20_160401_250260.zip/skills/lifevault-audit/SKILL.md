---
name: lifevault-audit
description: "Audit recent LifeVault sessions for missed important context, stale or conflicting facts, retrieval failures, and small evidence-backed system improvements."
---

# Audit how the system actually worked


LifeVault is at `D:\PerfectLife\LifeVault`. Read `00 System/Start.md` and `00 System/Memory rules.md` before personal-memory work. Read relevant current notes, not the whole vault. If unavailable, disclose that limitation; never create a replacement vault silently. Save ordinary important information automatically with provenance and briefly report the save. Sensitive information requires specific permission before collection/use/storage. No passwords, tokens, recovery codes, full payment details, or identity documents.


Default scope: the last seven calendar days in the current timezone, or the user's requested period. Read `00 System/Changes.md`, recent review notes, relevant journal files, and the canonical notes they changed. Start with paths and dates, then content. Do not load the full archive. Do not inspect old vaults to fill gaps.

## Checks
1. **Missed capture:** Compare meaningful statements, decisions, constraints, commitments, outcomes, and blockers in available sessions to their canonical notes. This is the highest-priority check because earlier systems missed key facts. Label the coverage denominator; inaccessible or unsaved conversations cannot be audited.
2. **Truth and freshness:** Confirm provenance; identify inferences presented as facts, edits mistaken for confirmations, contradictions, and facts beyond review dates. An overdue review does not prove falsehood.
3. **Continuity:** Can the current priority, last verified project result, blocker, next action, and latest learning attempt be found from the startup links? Check three to five real retrieval questions if enough evidence exists; cite answers and count failures. With no history, report insufficient data rather than inventing a trend.
4. **Structure:** Look for duplicate authoritative facts, broken links, oversized startup notes, unprocessed inbox items, and notes with no useful retrieval route. Don't demand every note link to every other note.
5. **Learning:** Compare assisted and independent attempts, delayed recall, and repeated misconceptions. Do not confuse notes written or exercises generated with learning.
6. **Privacy and durability:** Check permission metadata when relevant without exposing payloads. Check latest backup and restore evidence; a plan isn't a completed backup. Confirm whether installed skills and global startup instructions are included in recovery material.

## Improve proportionally
Write `08 Reviews/YYYY-MM-DD <scope>.md` using the Audit template. Each finding needs an exact note/section, evidence, consequence, and proposed change. Separate defects from optional preferences. Recommend at most one to three changes unless serious issues require more.

Fix reversible, unambiguous link/metadata/routing errors within the authorized audit; record before/after and verify. Do not silently decide disputed facts, change privacy permissions, perform broad restructuring, delete history, or install plugins. Stage a concrete proposal for consequential or ambiguous changes, explain why a decision is needed, and continue independent work. No ritual approval for ordinary repairs.

Record changes in `00 System/Changes.md`. Choose a short experiment, a measurable success criterion, and a rollback path. Default evaluation over the next week of use; do not create a recurring automation unless requested. Ask one high-value follow-up about observed friction. See `00 System/Research basis.md` for design assumptions.
