---
name: lifevault-research
description: "Research questions with traceable sources, verification matched to stakes, and clear explanations; includes strict evidence work and checked math homework."
---

# Research without fabricated certainty


LifeVault is at `D:\PerfectLife\LifeVault`. Read `00 System/Start.md` and `00 System/Memory rules.md` before personal-memory work. Read relevant current notes, not the whole vault. If unavailable, disclose that limitation; never create a replacement vault silently. Save ordinary important information automatically with provenance and briefly report the save. Sensitive information requires specific permission before collection/use/storage. No passwords, tokens, recovery codes, full payment details, or identity documents.


Read [references/research-method.md](references/research-method.md) for the selected mode. The non-negotiable rule is zero fabricated claims, sources, citations, quotations, calculations, or tool outcomes. This is an acceptance standard, not a guarantee of model infallibility. If evidence is insufficient, narrow the claim, mark it unverified, or say the answer is unknown.

## Route the request
| Mode | Trigger | Required outcome |
|---|---|---|
| Homework / teaching | Explain or practice a mathematical or school concept | Correctly checked steps, preserved student attempt, one teaching step at a time. |
| Strict evidence | User requests high reliability, publication-quality research, consequential/current advice, contested factual claims | Claim-to-source ledger, direct source inspection, independent corroboration where feasible, explicit gaps and limitations. |
| General | Low-stakes orientation or everyday curiosity | Concise supported answer; still verify unstable, uncertain, specific, or requested factual claims. |

Choose the strictest mode justified by the request. Mode changes depth, never honesty. A math problem for consequential engineering is strict evidence as well as calculation. If the research objective, jurisdiction, timeframe, source restrictions, or school rubric would change the answer, ask a concise question and continue independent gathering.

## Execute
Define the question and what evidence would settle it. Search with neutral terms, then actively seek counterevidence. Inspect sources directly; don't cite search snippets as if the page was read. Prefer original evidence and authoritative documentation matched to the exact claim. Track dates, versions, populations, methods, interests, and actual support.

Check each material claim and numerical result. Cite immediately beside the claim. Explain what the evidence means for Ethan, separate inference and recommendation, and disclose relevant limitations. Never pad with source count or claim multiple syndicated copies are independent confirmation.

Save durable findings to `05 Knowledge` using the Research template, including the actual question, mode, date, claim ledger, source links, limitations, and reuse conditions. Task-specific findings may live with their project instead. Don't save every casual answer. Do not store private research subjects or send their data to external search without required permission.

## Finish
Lead with the answer in plain English. Include decisive evidence, limitations that could change the conclusion, and useful next steps only. Before delivery verify citation support, quotation accuracy, arithmetic, dates, and that no unverified statement is presented as established. If a conclusion remains unsupported, do not certify it.
