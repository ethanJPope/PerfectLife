---
name: lifevault-resume
description: "Recover relevant LifeVault context at the start of a task or when continuing a project, lesson, decision, or interrupted conversation."
---

# Resume from evidence


LifeVault is at `D:\PerfectLife\LifeVault`. Read `00 System/Start.md` and `00 System/Memory rules.md` before personal-memory work. Read relevant current notes, not the whole vault. If unavailable, disclose that limitation; never create a replacement vault silently. Save ordinary important information automatically with provenance and briefly report the save. Sensitive information requires specific permission before collection/use/storage. No passwords, tokens, recovery codes, full payment details, or identity documents.


1. Read `00 System/Context.md` and `03 Projects/Projects.md`. For a lesson, also read `06 Learning/Learning.md`. Select the note that matches the current request.
2. Read the selected canonical note, latest linked handoff, and only the relevant profile constraints. Check actual completion evidence and dates. Verify external files or repository state when needed; a prior plan isn't proof an action occurred.
3. Respond briefly: last verified result; unresolved issue; next concrete action. Mention outdated or uncertain context only when it matters. Use a file citation for consequential remembered context.
4. If multiple projects fit, ask a specific choice. If the handoff is missing, search targeted journal terms/date ranges, then ask for the missing detail. Do not load all chat history or archived notes as a substitute for a missing fact.
5. Continue the user's authorized work. At a milestone update the handoff following Memory rules. Record any retrieval failure as a non-sensitive friction item for audit.

Do not confuse “file last modified” with “user last confirmed.” Do not promote a speculative future event to current reality because its planned date passed. Ask proactively when missing context could cause repeated work. If the user requests no memory use, follow that instruction for the session.
