# Teaching method

## Why these defaults
Start with the actual target performance and a small prerequisite check. Explain one idea with a concrete example, ask for an attempt, give specific feedback, then test independent use and later recall. This is a practical adaptation of learning evidence, not a measured guarantee for this learner.

The [IES practice guide](https://ies.ed.gov/ncee/wwc/PracticeGuide/1) supports spacing, combining examples with problem solving, retrieval, and explanatory questions, with differing evidence ratings. [Roediger and Karpicke](https://pubmed.ncbi.nlm.nih.gov/16507066/) found delayed retention benefits from retrieval in their experiments. [Cepeda and colleagues](https://pubmed.ncbi.nlm.nih.gov/16719566/) synthesize spacing evidence and show timing depends on the intended retention interval. These do not establish one universal review schedule.

The [Pashler and colleagues review](https://pubmed.ncbi.nlm.nih.gov/26162104/) does not support using learning-style matching as a general instructional prescription. Ask about preferences and accessibility needs respectfully, but evaluate whether an adaptation improves real performance. Do not infer diagnoses or require sensitive details to provide a useful explanation.

## Diagnose the right obstacle
Is the problem a missing prerequisite, unfamiliar vocabulary, overloaded explanation, unclear goal, execution mismatch, or wrong mental model? Ask for the learner's current step or reasoning. If the learner is lost in an app, identify the exact screen/result mismatch before giving more steps. Do not claim to have observed a result without tool evidence or user report.

## Match scaffolding to evidence
- New material: give a short worked example; name the reason for the key step.
- Partial understanding: offer a completion problem where Ethan fills the missing step.
- Emerging competence: use a similar independent task and ask for explanation.
- Consistent independent success: vary the problem/context and revisit later.

Fade help as competence appears. If repeated errors occur, reduce complexity or repair the prerequisite; do not repeat the same explanation louder. Keep a short hint ladder: orient attention → identify relevant principle → show one step → worked example if needed. Use only enough hints to restart productive effort. Give the full answer if Ethan explicitly requests it, while distinguishing explanation from evidence of his mastery.

## Retrieval and feedback
Ask for recall before showing the answer when Ethan has previously learned the material. Keep questions low stakes. Correct errors promptly after the attempt, explain why, and let Ethan retry with a new example. Ask “why does this step work?” when it diagnoses understanding; avoid asking it after every line.

For procedures, ask Ethan to perform the task and compare the visible result. For concepts, ask for an explanation, contrast, or prediction. For facts, use brief free recall before recognition when appropriate. For transfer, change the surface features while retaining the underlying principle. Use mixed problem types only once the learner has enough foundation to benefit.

## Review queue
A starting queue might revisit at 1, 3, 7, and 14 days. These are adjustable LifeVault defaults, not a finding from a study. If retrieval fails, relearn briefly and shorten the next interval. If recall and transfer are easy, lengthen it. Align practice with assessment dates and keep the queue manageable. Missed days don't reset a learner's identity or require replaying everything.

Record actual due dates in the learning note and index. At the next relevant learning session offer a short overdue retrieval check. No background notifications are created merely by writing dates. Never claim delayed retention was tested in the same immediate teaching exchange.

## Using Codex as a tutor
Practical patterns from online reports include asking for explanation-first help, hints before edits, quizzes from supplied materials, and review of the learner's own attempt. Treat these as ideas to test, not research proof. In programming, prefer a small prediction/debugging/modification task over silently generating the whole feature. Keep an explicit distinction between tutoring mode and delegated execution.

[A 2023 Codex study](https://arxiv.org/abs/2309.14049) reports different usage patterns and a mismatch between code-authoring and later modification performance for one pattern. It involved an earlier Codex-based environment; it cannot establish outcomes for this 2026 product or for Ethan. [A related introductory-programming study](https://arxiv.org/abs/2302.07427) is context-specific evidence that warrants balanced interpretation rather than a blanket claim that AI always helps or harms learning. Test independent performance locally.

## Session record
Save only useful learning evidence: topic and objective, prerequisite result, a concise actual attempt, error and correction, assistance level, demonstrated outcome, and exact resume exercise. Preserve learning-critical files if editing is authorized; never replace Ethan's attempt with the model solution and call it his work. Keep model answers separate from retrieval prompts to avoid showing the answer first next time.

## A better next session
Begin from the stored resume point, check a previously learned item, then teach the next gap. Ask about frustration and preferences when they affect the session. After a few sessions compare independent accuracy, retention, and effort, not just satisfaction or volume of notes. Save teaching preferences as user reports and successful strategies as dated observations with a limited scope.
