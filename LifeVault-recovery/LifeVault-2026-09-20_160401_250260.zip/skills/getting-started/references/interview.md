# Interview bank — 120 prompts

## How to use
The first three questions in each module are core candidates (36 total). Start with those that are still unanswered; choose follow-ups based on the answer. The full bank is optional depth, not an hour-long checklist. Module budgets sum to roughly 60 minutes; allow 55–75 minutes plus breaks and deeper follow-up. Skip irrelevant modules or defer them explicitly. Track IDs in the vault's Onboarding note.

Open questions precede suggestions. Ask about a recent example to separate aspirations from actual behavior. One question should test one idea. Verify your interpretation, not the user's identity. Avoid leading language, personality diagnoses, or pressure to disclose. This is a custom interview, not a clinical assessment or validated test.

Only request sensitive contents after specific permission for that category and purpose. No core question requires birth date, exact address, income, diagnoses, identifying family details, passwords, or payment information. If a user volunteers sensitive material, avoid restating or storing it while permission is unresolved. Record “topic deferred” without the payload.

The purpose is to route actionable context, not build a complete dossier. Source-aware saving, concrete examples, agency, current priorities, constraints, baseline performance, retrieval tests, and correction mechanisms were selected to address the requested system. See `D:\PerfectLife\LifeVault\00 System\Research basis.md` for supporting sources and limitations.

## A. A useful system

Planning budget: 5 minutes.
Save useful answers to: `02 Profile/Preferences.md; 03 Projects/LifeVault setup.md`. Create only notes justified by actual answers.

- **A01 · core** — What would LifeVault remember for you that would make this week easier?
- **A02 · core** — Describe the last time forgetting context made you repeat work.
- **A03 · core** — What would convince you after three weeks that this system is working?
- **A04** — Which part of a previous system first became hard to use?
- **A05** — Which important information did earlier systems fail to save?
- **A06** — What did you actually like about an earlier setup?
- **A07** — What would make you stop using this vault?
- **A08** — How much daily upkeep would feel acceptable?
- **A09** — When you open LifeVault, what do you want to see first?
- **A10** — Which one real situation should we use as our first retrieval test?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## B. Memory and boundaries

Planning budget: 5 minutes.
Save useful answers to: `02 Profile/Memory preferences.md; 00 System/Memory rules.md only for explicit policy choices`. Create only notes justified by actual answers.

- **B01 · core** — Beyond the current rules, is there any category you want excluded from memory?
- **B02 · core** — What should trigger a question before I save an otherwise ordinary detail?
- **B03 · core** — How would you like me to tell you what I saved?
- **B04** — Should a passing interest remain a temporary note until you confirm it matters?
- **B05** — When your preference changes, how would you like the old preference described?
- **B06** — Are there situations when you want to use Codex without using personal context?
- **B07** — How should I handle uncertain statements such as “maybe I want to do this”?
- **B08** — Are there names you would rather replace with roles or nicknames?
- **B09** — Do you want an optional discussion of permissions for sensitive categories later, without sharing the details now?
- **B10** — What would help you trust that a correction or forgetting request was handled?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## C. Life today

Planning budget: 5 minutes.
Save useful answers to: `02 Profile/Current life.md; relevant 04 Areas notes`. Create only notes justified by actual answers.

- **C01 · core** — Which two or three parts of life need support first?
- **C02 · core** — What are your main roles or responsibilities right now?
- **C03 · core** — What upcoming change could make today’s context outdated?
- **C04** — What does an ordinary weekday look like at a high level?
- **C05** — What does a typical weekend need to leave room for?
- **C06** — Which recurring responsibilities do you often have to remember yourself?
- **C07** — What is already going well that this system should protect?
- **C08** — What constraint should I account for when suggesting plans?
- **C09** — Which life area do you intentionally want to leave unstructured?
- **C10** — Is there a role or responsibility I might otherwise overlook?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## D. Direction and priorities

Planning budget: 5 minutes.
Save useful answers to: `02 Profile/Goals.md; 03 Projects notes only for actionable outcomes`. Create only notes justified by actual answers.

- **D01 · core** — What is the most important outcome you want in the next three months?
- **D02 · core** — Why does that outcome matter to you?
- **D03 · core** — How would you recognize enough progress to call it worthwhile?
- **D04** — What is another goal competing for the same time?
- **D05** — Which goal is your own choice rather than an expectation from others?
- **D06** — What would you like to be able to do a year from now?
- **D07** — What would you like life to make room for over the next three to six years?
- **D08** — What are you deliberately not pursuing right now?
- **D09** — What tradeoff are you unwilling to make for a goal?
- **D10** — What evidence would tell you a goal should change?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## E. A real project handoff

Planning budget: 8 minutes.
Save useful answers to: `03 Projects/<actual project>.md; 03 Projects/Projects.md`. Create only notes justified by actual answers.

- **E01 · core** — Which current project should we make resumable first?
- **E02 · core** — What is the last thing you actually completed on it?
- **E03 · core** — What is the next concrete action you could take?
- **E04** — What will count as finished for this project?
- **E05** — Where are the actual files or artifacts for this project?
- **E06** — What is blocking the next action?
- **E07** — What decision has already been made that I should not reopen without a reason?
- **E08** — Which attempted approach did not work?
- **E09** — Is there a real deadline, and what is its source?
- **E10** — What should another chat know so it does not make you start over?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## F. Responsibilities and commitments

Planning budget: 4 minutes.
Save useful answers to: `04 Areas/<actual area>.md; linked project for dated deliverable`. Create only notes justified by actual answers.

- **F01 · core** — What recurring responsibility most needs a reliable checklist or memory?
- **F02 · core** — What commitment have you already made that must not be confused with an idea?
- **F03 · core** — Where is the authoritative place you currently check deadlines?
- **F04** — What does good-enough completion look like for that responsibility?
- **F05** — Which task often gets delayed because its next step is unclear?
- **F06** — Which recurring task could use a reusable procedure?
- **F07** — Who depends on an outcome from you, described by role if preferred?
- **F08** — What information needs rechecking before you act on it?
- **F09** — What should happen when a deadline moves?
- **F10** — Which responsibility should stay outside this vault?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## G. Time and sustainable effort

Planning budget: 4 minutes.
Save useful answers to: `02 Profile/Schedule.md; 04 Areas/Planning.md if useful`. Create only notes justified by actual answers.

- **G01 · core** — When is it realistic for you to use this system?
- **G02 · core** — How much time can a typical work or learning session have?
- **G03 · core** — What is the earliest sign a plan has become too demanding?
- **G04** — At what times do you usually find focused work easiest?
- **G05** — What interruptions should a plan expect?
- **G06** — What helps you restart after several days away?
- **G07** — What is the smallest useful version of a busy-day check-in?
- **G08** — How many simultaneous priorities feel manageable?
- **G09** — Do due-date reminders help, or do they become noise?
- **G10** — What kind of rest or free time should plans leave untouched?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## H. Learning that sticks

Planning budget: 7 minutes.
Save useful answers to: `02 Profile/Learning preferences.md; 06 Learning/<actual topic>.md`. Create only notes justified by actual answers.

- **H01 · core** — What do you want to learn to do independently first?
- **H02 · core** — Can you show or explain a small example of what you already know about it?
- **H03 · core** — Describe a time you learned something and remembered it well.
- **H04** — What is a recent explanation that left you confused?
- **H05** — What do you want me to do first when you say you are lost?
- **H06** — When should I offer a hint versus show a worked example?
- **H07** — What kind of practice feels connected to your actual goals?
- **H08** — Is there an assessment or performance date we should plan toward?
- **H09** — What would you be willing to try recalling without notes next time?
- **H10** — How should we check whether a teaching change actually helped?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## I. Research and decisions

Planning budget: 4 minutes.
Save useful answers to: `02 Profile/Research preferences.md; actual research project if present`. Create only notes justified by actual answers.

- **I01 · core** — What kinds of questions will you ask me to research most often?
- **I02 · core** — For which uses would a factual error be especially costly?
- **I03 · core** — What makes a source explanation understandable to you?
- **I04** — When do you prefer a quick answer versus a detailed evidence trail?
- **I05** — Do your school or work tasks have source rules I should follow?
- **I06** — When evidence conflicts, what decision are you usually trying to make?
- **I07** — Would one worked example help you understand a numerical claim?
- **I08** — What source or type of explanation have you found misleading before?
- **I09** — What should I do when a reliable answer cannot be established?
- **I10** — What would make you want to read the original source yourself?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## J. Tools and retrieval

Planning budget: 5 minutes.
Save useful answers to: `02 Profile/Tools.md; 00 System/Maintenance.md for explicit setup decisions`. Create only notes justified by actual answers.

- **J01 · core** — Which devices need access to LifeVault?
- **J02 · core** — Where do important notes and project files currently arrive?
- **J03 · core** — Do you have an existing approved backup destination for the new vault?
- **J04** — How do you prefer to capture a thought when away from your computer?
- **J05** — What words would you search to find a project you paused last month?
- **J06** — What file or app should remain the authoritative source outside this vault?
- **J07** — Which device should produce backup copies?
- **J08** — Would you prefer a small Home page or a larger dashboard?
- **J09** — What would make the note titles easier for you to recognize?
- **J10** — If you changed computers tomorrow, what would you expect to keep working?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## K. Communication and support

Planning budget: 4 minutes.
Save useful answers to: `02 Profile/Communication.md; no sensitive relationship payload without specific permission`. Create only notes justified by actual answers.

- **K01 · core** — When should I ask an unprompted question instead of proceeding on an assumption?
- **K02 · core** — How should I point out that your current plan conflicts with an earlier goal?
- **K03 · core** — What response length is most useful when you are trying to get something done?
- **K04** — How do you want me to respond when you seem frustrated?
- **K05** — What would make a correction feel useful rather than patronizing?
- **K06** — When would you rather see a diagram than more text?
- **K07** — How should I distinguish a recommendation from a decision you have made?
- **K08** — What is an example of taking over too much when helping you?
- **K09** — Would remembering non-identifying collaboration roles help any current project?
- **K10** — What should I never assume simply because you have not replied?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.

## L. Verify and refine

Planning budget: 4 minutes.
Save useful answers to: `00 System/Onboarding.md; 08 Reviews/<date> Onboarding.md`. Create only notes justified by actual answers.

- **L01 · core** — Looking at the saved summary, what is wrong or missing?
- **L02 · core** — Which real question should a new chat now be able to answer?
- **L03 · core** — What is the first change you want us to evaluate over the next week?
- **L04** — Which saved detail might change soon?
- **L05** — Did any interview question feel unnecessary or uncomfortable?
- **L06** — Which topic would you like to explore more later?
- **L07** — What is the easiest way for you to report that memory failed?
- **L08** — What should a weekly audit tell you in a few sentences?
- **L09** — How will we tell whether maintenance is costing more than the system saves?
- **L10** — What important question did I fail to ask?

Adaptive follow-up: ask for a concrete example, clarify a word that changes the action, or ask what has changed since the source date. Do not automatically ask all three.
