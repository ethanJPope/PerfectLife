---
name: getting-started
description: "Conduct or resume Ethan\u2019s thorough LifeVault onboarding interview; establish personal context, priorities, permissions, and real project handoffs."
---

# Getting started


LifeVault is at `D:\PerfectLife\LifeVault`. Read `00 System/Start.md` and `00 System/Memory rules.md` before personal-memory work. Read relevant current notes, not the whole vault. If unavailable, disclose that limitation; never create a replacement vault silently. Save ordinary important information automatically with provenance and briefly report the save. Sensitive information requires specific permission before collection/use/storage. No passwords, tokens, recovery codes, full payment details, or identity documents.


## Intended experience
Run a thoughtful, roughly hour-long conversation, not a questionnaire dump. Aim for 55–75 minutes of user participation across as many sessions as needed. The question bank has core prompts plus optional depth; answering every prompt can take much longer. Time estimates are planning assumptions. Never claim an hour passed without checking time.

Read `00 System/Onboarding.md`, `02 Profile/Preferences.md`, and [references/interview.md](references/interview.md). Begin at the recorded resume point. Do not import old vaults or other chats to prefill personal answers. Existing global working agreements are behavior rules, not evidence for new biographical facts.

## Conversation loop
1. Explain briefly that answers can be short, skipped, revisited, or kept out of memory. Use the current user’s explicit saving permissions; don't repeatedly request blanket permission already given.
2. Select one to three related unanswered prompts. Ask one at a time when the answer needs reflection or the user seems overloaded. Start with open questions and ask for a recent concrete example before offering categories. Adapt phrasing and follow-ups; IDs are for continuity, not something Ethan must manage.
3. Reflect back only what matters. Distinguish goals from current behavior, facts from uncertainty, and Ethan's words from your interpretation. Don't infer diagnoses, age, personality types, income, family structure, or learning style.
4. Save useful non-sensitive answers immediately into the right canonical notes and a concise session source. Record question ID, answered/skipped/later/not-applicable, destination, evidence date, and next follow-up in Onboarding. Do not save sensitive payloads while awaiting consent. Do not create empty profile files for skipped domains.
5. Every 10–15 minutes or at a topic boundary, offer a short recap and an opportunity to correct or pause. Ask a focused question if an important missing fact would otherwise be lost. Avoid asking again what was already answered; mark existing evidence against the matching question ID.
6. At a pause, save the precise resume question, unresolved assumptions, and next action. A stopped interview is paused, not failed or complete.

## A useful finish
Produce a brief profile of confirmed essentials, one actionable project handoff if applicable, a realistic learning starting point if requested, and a short list of deferred topics. Run a retrieval demonstration from saved files: answer “What matters now, where did we stop, and what comes next?” Cite actual notes and invite correction.

Mark core-complete only when completion criteria in Onboarding are met or specific items were explicitly deferred. Mark expanded-complete only when the chosen deeper modules are handled; never imply every question was answered. Preserve unknowns. Update Context and Projects with links, not transcript copies. Ask Ethan what the interview missed.

## Quality standard
The bank is a custom operational interview, not a validated psychological assessment. Its question-writing principles are adapted from Pew's survey guidance; motivation/learning prompts are informed by educational research. See `00 System/Research basis.md` for sources and limits. Do not treat collected self-reports as independent proof of performance.
