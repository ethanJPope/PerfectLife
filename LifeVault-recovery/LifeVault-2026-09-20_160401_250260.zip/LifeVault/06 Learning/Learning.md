---
type: index
status: active
created: 2026-09-20
updated: 2026-09-20
schema: 1
---

# Learning

No topics assessed yet. Run `$lifevault-teach` with a topic and an outcome you want to achieve.

| Topic | Demonstrated level | Next practice | Review due |
|---|---|---|---|

Review dates are a queue checked when this vault is used. They are not background reminders.
