---
type: index
status: active
created: 2026-09-20
updated: 2026-09-20
schema: 1
---

# Projects

| Project | Status | Last evidence | Next action |
|---|---|---|---|
| [[03 Projects/LifeVault setup]] | active | 2026-09-20 | Open the vault; start a fresh task with `$getting-started`. |

Add a project when Ethan names a concrete outcome. Do not invent projects from interests.
