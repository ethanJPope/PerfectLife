---
type: system
status: active
created: 2026-09-20
updated: 2026-09-20
schema: 1
---

# System changes

## 2026-09-20 — v1.0
Created a fresh plain-Markdown system with current notes plus dated sessions, explicit provenance, six specialized skills, and a compact startup route. Chosen as a practical starting design; no claim that this is the universally best personal knowledge system.

Future entries: observed problem → evidence → smallest change → verification → rollback path. Avoid redesigning on speculation.
